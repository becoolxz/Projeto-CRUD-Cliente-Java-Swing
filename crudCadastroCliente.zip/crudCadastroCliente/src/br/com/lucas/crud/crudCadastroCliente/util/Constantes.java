/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.lucas.crud.crudCadastroCliente.util;

/**
 *
 * @author tiano
 */
public class Constantes {
    
    public static final String CONEXAO_BD_PROPERTIES = "br.com.lucas.crud.crudCadastroCliente.util.config_bd";

    public static final String CONEXAO_DB_DRIVER = "conexao.driver.mysql";
	
    public static final String CONEXAO_DB_URL = "conexao.url";
	
    public static final String CONEXAO_DB_USER = "conexao.user";
	 
    public static final String CONEXAO_BD_PASSWORD = "conexao.password";
    
}
